/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.8-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: sucursal_2
-- ------------------------------------------------------
-- Server version	10.11.8-MariaDB-0ubuntu0.24.04.1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Clientes`
--

DROP TABLE IF EXISTS `Clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Clientes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(100) DEFAULT NULL,
  `ApellidoPaterno` varchar(100) DEFAULT NULL,
  `ApellidoMaterno` varchar(100) DEFAULT NULL,
  `RFC` char(18) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `RFC` (`RFC`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Clientes`
--

LOCK TABLES `Clientes` WRITE;
/*!40000 ALTER TABLE `Clientes` DISABLE KEYS */;
INSERT INTO `Clientes` VALUES
(1,'Jorge','Hernández','Salazar','JHSH940305HDFRNL07'),
(2,'Laura','Pérez','Martínez','LPM890702MDFLZZ06'),
(3,'Francisco','González','Jiménez','FGJ780405HDFGZC03'),
(4,'Cristina','Moreno','López','CMLR820601HDFMNN10'),
(5,'Ricardo','Díaz','Sánchez','RDS960215HDFCLF09'),
(6,'Verónica','Luna','Gómez','VLG710607MDFRNL12'),
(7,'Miguel','Cabrera','Serrano','MCS880901HDFNZZ13'),
(8,'Elena','Vázquez','Hernández','EVH810507MDFLZN05'),
(9,'Carlos','Alvarado','Pacheco','CAP990312HDFLRN15'),
(10,'Patricia','Chavez','Morales','PCM920109MDFNTZ16'),
(11,'Juan','Rodríguez','Hernández','JRH920412HDFRSL03'),
(12,'Carlos','Mendoza','Fernández','CMF900423HDFLNS07'),
(13,'Ana','Sánchez','Ramírez','ASR951210MDFNSJ09'),
(14,'Ricardo','Torres','Díaz','RTD900616HDFRTZ01'),
(15,'Juan','Martínez','González','JMG870803HDFMLR06');
/*!40000 ALTER TABLE `Clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Direcciones`
--

DROP TABLE IF EXISTS `Direcciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Direcciones` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Calle` varchar(100) DEFAULT NULL,
  `Numero` varchar(10) DEFAULT NULL,
  `Colonia` varchar(100) DEFAULT NULL,
  `Estado` varchar(50) DEFAULT NULL,
  `CP` char(5) DEFAULT NULL,
  `idCliente` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `idCliente` (`idCliente`),
  CONSTRAINT `Direcciones_ibfk_1` FOREIGN KEY (`idCliente`) REFERENCES `Clientes` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Direcciones`
--

LOCK TABLES `Direcciones` WRITE;
/*!40000 ALTER TABLE `Direcciones` DISABLE KEYS */;
INSERT INTO `Direcciones` VALUES
(1,'Avenida del Trabajo','321','Colonia Vallejo','Morelia','58000',1),
(2,'Calle Morelos','456','Iztapalapa','Morelia','58000',2),
(3,'Calle del Río','789','Nezahualcóyotl','Pátzcuaro','61600',3),
(4,'Calle de la Luna','101','Naucalpan','Pátzcuaro','61600',4),
(5,'Avenida Revolución','102','Ecatepec','Morelia','58000',5),
(6,'Calle de los Olivos','203','Gustavo A. Madero','Morelia','58000',6),
(7,'Callejón del Parque','404','Atlixco','Morelia','58000',7),
(8,'Calle Pino Suárez','101','Tlalnepantla','Morelia','58000',8),
(9,'Callejón del Amor','908','Pátzcuaro','Pátzcuaro','61600',9),
(10,'Calle Emiliano Zapata','567','Texcoco','Pátzcuaro','61600',10),
(11,'Callejón del Lago','123','Colonia Primavera','Morelia','58000',6),
(12,'Avenida Revolución','456','Loma de Santa María','Morelia','58000',7),
(13,'Callejón del Pilar','789','Centro Histórico','Morelia','58000',8),
(14,'Calle Las Fuentes','234','La Paloma','Pátzcuaro','61600',9),
(15,'Avenida Constitución','678','La Estación','Pátzcuaro','61600',10);
/*!40000 ALTER TABLE `Direcciones` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-07 23:49:15
