/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.8-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: sucursal_1
-- ------------------------------------------------------
-- Server version	10.11.8-MariaDB-0ubuntu0.24.04.1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Clientes`
--

DROP TABLE IF EXISTS `Clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Clientes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(100) DEFAULT NULL,
  `ApellidoPaterno` varchar(100) DEFAULT NULL,
  `ApellidoMaterno` varchar(100) DEFAULT NULL,
  `RFC` char(18) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `RFC` (`RFC`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Clientes`
--

LOCK TABLES `Clientes` WRITE;
/*!40000 ALTER TABLE `Clientes` DISABLE KEYS */;
INSERT INTO `Clientes` VALUES
(1,'Manolito','Petro','Silva','MAPS547813HMNPTNV4'),
(2,'Ana','López','Martínez','ALM980302MDFSRN05'),
(3,'Carlos','Ramírez','Hernández','CARH750120HDFLNN01'),
(4,'Patricia','González','Sánchez','PAGS930509MDFNZN03'),
(5,'Luis','Martínez','Pérez','LMPU890808HDFLLS02'),
(6,'Isabel','García','Mendoza','IGM100201MDFGZR07'),
(7,'José','Rodríguez','Vázquez','JRV120603HDFRNN12'),
(8,'Sofía','Hernández','Flores','SHF860304MDFLNZ06'),
(9,'Felipe','Gutiérrez','Morales','FGM960809MDFNTZ08'),
(10,'Marta','Ramírez','Gómez','MRG111212MDFRSN10'),
(11,'Juan','López','González','JLG880612HDFLNX01'),
(12,'Carlos','Pérez','Ramírez','CPR930303HDFPRZ02'),
(13,'Ana','Martínez','García','AMG950409MDFRZC03'),
(14,'Ricardo','González','Martínez','RGM910512HDFMNT04'),
(15,'Juan','Gómez','Torres','JGT850314HDFMLR05'),
(16,'Carlos','Lopez','Gutierrez','CALG254803HMNUYTA8'),
(17,'Kevin','Jones','Smith','LOGI235689HMNPTNG3'),
(18,'Bryan','Smith','White','BRSW582301HMNPVTA5');
/*!40000 ALTER TABLE `Clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Direcciones`
--

DROP TABLE IF EXISTS `Direcciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Direcciones` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Calle` varchar(100) DEFAULT NULL,
  `Numero` varchar(10) DEFAULT NULL,
  `Colonia` varchar(100) DEFAULT NULL,
  `Estado` varchar(50) DEFAULT NULL,
  `CP` char(5) DEFAULT NULL,
  `idCliente` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `idCliente` (`idCliente`),
  CONSTRAINT `Direcciones_ibfk_1` FOREIGN KEY (`idCliente`) REFERENCES `Clientes` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Direcciones`
--

LOCK TABLES `Direcciones` WRITE;
/*!40000 ALTER TABLE `Direcciones` DISABLE KEYS */;
INSERT INTO `Direcciones` VALUES
(1,'Andadores','55','Flores','Guanajuato','75000',1),
(2,'Avenida Insurgentes','1234','Nápoles','Morelia','58000',2),
(3,'Callejón de la Amargura','567','Centro Histórico','Pátzcuaro','61600',3),
(4,'Calle del Sol','789','Colonia Roma','Morelia','58000',4),
(5,'Avenida Reforma','1011','Polanco','Pátzcuaro','61600',5),
(6,'Calle de los Pinos','234','Tacubaya','Morelia','58000',6),
(7,'Callejón San Felipe','890','La Condesa','Morelia','58000',7),
(8,'Calle de las Lomas','1012','Lomas de Chapultepec','Pátzcuaro','61600',8),
(9,'Calle Victoria','345','Santa Fe','Morelia','58000',9),
(10,'Calle Hidalgo','678','Norte','Morelia','58000',10),
(11,'Andadores','55','Flores','Guanajuato','75000',1),
(12,'Avenida Insurgentes','789','Nápoles','Morelia','58000',2),
(13,'Callejón de la Paz','123','Colonia 2000','Pátzcuaro','61600',3),
(14,'Calle Morelos','234','Centro','Morelia','58000',4),
(15,'Calle Revolución','567','Colonia Obrera','Pátzcuaro','61600',5),
(16,'Potosinos','665','Rios','Guanajuato','87000',16),
(17,'Motores','666','Autos','Michoacan','58000',17),
(18,'Flores','45','Petalos','Michoacan','58000',18);
/*!40000 ALTER TABLE `Direcciones` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-07 23:48:36
